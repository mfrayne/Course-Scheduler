/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author mfray
 */
public class MultiTableQueries {
    private static Connection connection;
    private static ArrayList<String> faculty = new ArrayList<String>();
    private static PreparedStatement getAllClassDescriptions;
    private static PreparedStatement getScheduledStudentsByClass;
    private static PreparedStatement getWaitlistedStudentsByClass;
    private static ResultSet resultSet;
    
    
    public static ArrayList<ClassDescription> getAllClassDescriptions(String semester){
        connection = DBConnection.getConnection();
        ArrayList<ClassDescription> schedules = new ArrayList<ClassDescription>();
        try
        {
            getAllClassDescriptions = connection.prepareStatement("SELECT course.coursecode,course.description,CLASS.seats FROM course JOIN CLASS ON course.coursecode = class.coursecode where semester = ?");
            getAllClassDescriptions.setString(1,semester);
            resultSet = getAllClassDescriptions.executeQuery();

            while(resultSet.next())
            {
                schedules.add(new ClassDescription(resultSet.getString(1),resultSet.getString(2),resultSet.getInt(3)));
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return schedules;
    }
    
    public static ArrayList<StudentEntry> getScheduledStudentsByClass(String semester, String courseCode){
        connection = DBConnection.getConnection();
        ArrayList<StudentEntry> students = new ArrayList<StudentEntry>();
        try
        {
            getScheduledStudentsByClass = connection.prepareStatement("SELECT student.lastname,student.firstname,student.studentID FROM student JOIN schedule ON schedule.studentID = student.studentID where schedule.semester = ? and schedule.coursecode = ? and schedule.status = 'Scheduled' order by schedule.timestamp");
            getScheduledStudentsByClass.setString(1,semester);
            getScheduledStudentsByClass.setString(2,courseCode);
            resultSet = getScheduledStudentsByClass.executeQuery();

            while(resultSet.next())
            {
                students.add(new StudentEntry(resultSet.getString(3),resultSet.getString(2),resultSet.getString(1)));
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return students;
    }
    public static ArrayList<StudentEntry> getWaitlistedStudentsByClass(String semester, String courseCode){
        connection = DBConnection.getConnection();
        ArrayList<StudentEntry> students = new ArrayList<StudentEntry>();
        try
        {
            getWaitlistedStudentsByClass = connection.prepareStatement("SELECT student.lastname,student.firstname,student.studentID FROM student JOIN schedule ON schedule.studentID = student.studentID where schedule.semester = ? and schedule.coursecode = ? and schedule.status = 'Waitlisted' order by schedule.timestamp");
            getWaitlistedStudentsByClass.setString(1, semester);
            getWaitlistedStudentsByClass.setString(2, courseCode);
            resultSet = getWaitlistedStudentsByClass.executeQuery();

            while(resultSet.next())
            {
                students.add(new StudentEntry(resultSet.getString(3),resultSet.getString(2),resultSet.getString(1)));
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return students;
    }
    
    
}
