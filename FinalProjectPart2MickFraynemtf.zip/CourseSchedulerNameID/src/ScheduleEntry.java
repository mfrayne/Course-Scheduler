
import java.util.Calendar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author mfray
 */
public class ScheduleEntry {
    private String semester;
    private String courseCode;
    private String studentID;
    private String status;
    private java.sql.Timestamp currentTimestamp;
    
    
    
    ScheduleEntry(String semester, String courseCode, String studentID, String status, java.sql.Timestamp currentTimestamp){
        this.semester = semester;
        this.courseCode = courseCode;
        this.studentID = studentID;
        this.status = status;
        this.currentTimestamp = currentTimestamp;
    }
    
    ScheduleEntry(String semester, String courseCode, String studentID){
        this.semester = semester;
        this.courseCode = courseCode;
        this.studentID = studentID;
        determineStatus();
        currentTimestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
    }
    
    private void determineStatus(){
        
        Connection connection = DBConnection.getConnection();
        int scheduledCount;
        int maxSeats;
        
        
        try
        {
            PreparedStatement getScheduleCount = connection.prepareStatement("select count(StudentID) from schedule where semester = ? and courseCode = ? and status = 'Scheduled'");
            getScheduleCount.setString(1, semester);
            getScheduleCount.setString(2, courseCode);
            ResultSet resultSet = getScheduleCount.executeQuery();
            
            resultSet.next();
            scheduledCount = resultSet.getInt(1);

            PreparedStatement getClassSeats = connection.prepareStatement("select seats from class where semester = ? and courseCode = ?");
            getClassSeats.setString(1, semester);
            getClassSeats.setString(2, courseCode);
            resultSet = getClassSeats.executeQuery();
            
            resultSet.next();
            maxSeats = resultSet.getInt(1);
            
            if(scheduledCount<maxSeats){
                status = "Scheduled";
            }
            else{
                status = "Waitlisted";
            }
        }
        catch(SQLException sqlException)
        {
            System.out.println("error occured at determineStatus in schedule entry");
            sqlException.printStackTrace();
        }
    }
    
    public String getSemester(){
        return semester;
    }
    public String getCourseCode(){
        return courseCode;
    }
    public String getStudentID(){
        return studentID;
    }
    public String getStatus(){
        return status;
    }
    public java.sql.Timestamp getTimestamp(){
        return currentTimestamp;
    }
    /*
    String getStudentID() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    */
}
